package com.example.model;

 
import lombok.Getter;
import lombok.Setter;
 
@Getter
@Setter
public class OrderDiscount {
 
    public Integer discount = 0;
}
