package com.example.model;
import lombok.Getter;
import lombok.Setter;
 
@Getter
@Setter

public class Customer {
    public Integer id;
    public String industry;
    public String subIndustry;
}
