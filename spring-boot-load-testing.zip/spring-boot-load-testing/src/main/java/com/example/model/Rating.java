
package com.example.model;
import lombok.Getter;
import lombok.Setter;
 
@Getter
@Setter

public class Rating {
    public Integer customerId;
    public String rating;
    public String ratingAgency;
}
